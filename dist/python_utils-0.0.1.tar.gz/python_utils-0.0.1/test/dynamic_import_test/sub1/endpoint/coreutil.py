print(f"coreutil loaded {__name__}")
