print(f"Util loaded {__name__}")
