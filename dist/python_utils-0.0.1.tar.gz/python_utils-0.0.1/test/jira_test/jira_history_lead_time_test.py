from python_utils.jira.jira_history import get_lead_time_in_days

print(get_lead_time_in_days("2024-01-01"))
print(get_lead_time_in_days("2024-01-01", "2024-03-01"))