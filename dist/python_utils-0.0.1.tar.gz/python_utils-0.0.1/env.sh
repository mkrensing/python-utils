#!/bin/bash
export PYTHON_UTILS_HOME=/media/dev2go/apps/python-utils
